# Event-Line Detection


Prerequisites:
---
1. OpenCV > 2.4.x
2. OpenMP
3. No other libs


---

Citation:
---
Our code has been expanded based on the foundation provided by Lu's code. Please cite the following paper if this you feel this code helpful.

```
@article{liu2023event,
title={Line-based event camera calibration},
author={Zibin Liu, Banglei Guan, Yang Shang, Zhenbao Yu and Qifeng Yu},
journal={Under review},
year={2023},
}
```

@article{lu2019fast,
title={Fast 3D Line Segment Detection From Unorganized Point Cloud},
author={Xiaohu, Lu and Yahui, Liu and Kai, Li},
journal={arXiv preprint arXiv:1901.02532},
year={2019},
}
```
